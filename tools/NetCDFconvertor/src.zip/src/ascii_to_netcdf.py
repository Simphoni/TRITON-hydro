from tkinter import filedialog
from tkinter import *

import netCDF4
import numpy as np

import os

import xml.etree.ElementTree as ET

input_file_name = ''

dem_attr_dict = {
    'ncols'     :   0.0,
    'nrows'     :   0.0,
    'xllcorner' :   0.0,
    'yllcorner' :   0.0,
    'cellsize'  :   0.0
}

def read_input_file_header(file_name, lines_of_header):
    with open(file_name, mode='r') as file:
        head = [next(file) for x in range(lines_of_header)]
    
    ret_str = ''

    for elem in head:
        elem = elem.split()
        
        elem_str = "{}:{};".format(elem[0], elem[1])
        
        ret_str += elem_str

    return ret_str

def read_input_file(file_name, lines_of_header):
    file = open(file_name, mode='r')

    for i in range(lines_of_header):
        next(file)
    
    inpArr = file.read().split()
    npArr = np.array(inpArr)
    npArr = npArr.astype(np.float32)

    file.close()

    return npArr

def select_output_file():
    last_known_folder = "~/"

    with open('prog_data/outputfile', 'r') as inputfile:
        try:
            last_known_folder = next(inputfile)
        except StopIteration:
            last_known_folder = "~/"

    root = Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    root.filename = filedialog.asksaveasfilename(initialdir = last_known_folder,title = "Select file",filetypes = (("NetCDF file","*.nc"),("all files","*.*")))

    if root.filename is not ():
        inputfile = open('prog_data/outputfile', 'w')
        inputfile.write(os.path.dirname(root.filename))
        inputfile.close()

    if not root.filename.endswith(".nc"):
        root.filename += ".nc"

    return root.filename


def create_nc_file(xml_config, input_file_name, lines_of_header):
    file = open("config/config.xml", mode="w")
    file.write(xml_config)
    file.close()

    tree = ET.parse("config/config.xml")
    root = tree.getroot()

    output_file_name = select_output_file()

    output_nc_file = netCDF4.Dataset(output_file_name, mode='w', format='NETCDF4')    
    
    dims = []

    for variable in root.findall('variable'):
        for dimensions in variable.findall('dimensions'):
            for d in list(dimensions):
                if d.tag not in dims:
                    output_nc_file.createDimension(d.tag, int(d.text))
                    dims.append(d.tag)
                    
    for variable in root.findall('variable'):
        attr_dict = {}

        name = variable.find('name')

        local_dims = []
        for dimensions in variable.findall('dimensions'):
            for d in list(dimensions):
                if d.tag not in local_dims:
                    local_dims.append(d.tag)
        
        var = output_nc_file.createVariable(name.text, 'f8', local_dims)

        for attributes in variable.findall('attributes'):
            for attr in list(attributes):
                try:
                    attr_dict[attr.tag] = float(attr.text)

                    if attr.tag in dem_attr_dict:
                        dem_attr_dict[attr.tag] = float(attr.text)
                except:
                    attr_dict[attr.tag] = attr.text

        if name.text == 'x':
            x = []
            for i in range(0, int(dem_attr_dict['ncols'])):
                cell_locs_x = 0.5 + i
                x.append(
                    (cell_locs_x * dem_attr_dict['cellsize']) + dem_attr_dict['xllcorner']
                )
            var[:] = x
        elif name.text == 'y':
            y = []
            for i in range(0, int(dem_attr_dict['nrows'])):
                cell_locs_y = dem_attr_dict['nrows'] - (0.5 + i)
                y_val = (cell_locs_y * dem_attr_dict['cellsize']) + dem_attr_dict['yllcorner']
                y.append(y_val)
            var[:] = y
        elif name.text == 'transverse_mercator':
            pass
        else:
            npArr = read_input_file(input_file_name, lines_of_header)
            npArr = npArr.reshape(var.shape)
            var[:] = npArr
                    
        var.setncatts(attr_dict)

    output_nc_file.close()

    return "done"

def select_file(lines_of_header):
    last_known_folder = "~/"

    with open('prog_data/inputfile', 'r') as inputfile:
        try:
            last_known_folder = next(inputfile)
        except StopIteration:
            last_known_folder = "~/"

    root = Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    root.filename =  filedialog.askopenfilename(initialdir = last_known_folder,title = "Select file",filetypes = (("all files","*.*"),("dem file","*.dem")))
    
    input_file_name = root.filename

    ret_str = ''
    if input_file_name is not '' and input_file_name is not ():
        inputfile = open('prog_data/inputfile', 'w')
        inputfile.write(os.path.dirname(input_file_name))
        inputfile.close()

        ret_str = read_input_file_header(input_file_name, lines_of_header)
        ret_str += root.filename

    print(ret_str)

    return ret_str

def select_prj_file():
    last_known_folder = "~/"

    with open('prog_data/prjfile', 'r') as inputfile:
        try:
            last_known_folder = next(inputfile)
        except StopIteration:
            last_known_folder = "~/"

    root = Tk()
    root.withdraw()
    root.wm_attributes('-topmost', 1)
    root.filename =  filedialog.askopenfilename(initialdir = last_known_folder,title = "Select file",filetypes = (("all files","*.*"),("projection file","*.prj")))

    prj_file_name = root.filename
    prj_string = ''

    if prj_file_name is not '':
        with open(prj_file_name) as file:
            prj_string = next(file)

        prjfile = open('prog_data/prjfile', 'w')
        prjfile.write(os.path.dirname(prj_file_name))
        prjfile.close()

    return prj_string