$(document).ready(function() {
    let tempate = {
        "?": "xml version=\"1.0\" encoding=\"utf-8\"",

        variables: {
            variable: []
        }
    }

    let variable_template = {
        name: "",

        dimensions: {

        },
        attributes: {

        }
    }

    let file_name = ''
    let prj_string = ''

    let has_n_cols = false;
    let has_n_rows = false;

    $('[data-toggle="popover"]').popover();

    $("#btn-add-dimension").click(function() {
        let dim_input = $('.dimension-input:first').clone();

        $(dim_input.find('.key')).val('');
        $(dim_input.find('.value')).val('');

        $(this).siblings(".dimension-input:last").after(dim_input);
    });

    $("#btn-add-attribute").click(function() {
        let attribute_input = $('.attribute-input:first').clone();

        $(attribute_input.find('.key')).val('');
        $(attribute_input.find('.value')).val('');

        $(this).siblings(".attribute-input:last").after(attribute_input);
    });

    $("#generate-xml").click(function() {
        let variableName = $("#variable-name-input").val();

        let _var = JSON.parse(JSON.stringify(variable_template));

        _var.name = variableName;

        $('.dimension-input').each(function(i, element) {
            let key = $(element).find(".key").val()

            _var.dimensions = {
                ..._var.dimensions,
                [$(element).find(".key").val()]: $(element).find(".value").val(),
            }
        });

        $('.attribute-input').each(function(i, element) {
            let key = $(element).find(".key").val()

            _var.attributes = {
                ..._var.attributes,
                [$(element).find(".key").val()]: $(element).find(".value").val(),
            }
        });

        _var.attributes = {
            ..._var.attributes,
            'esri_prj_string': $("#prj_string").html()
        }

        $('.dimension-input').each(function(i, element) {
            if ($(element).find('.key').val() == 'y' && !has_n_rows) {
                _var.attributes = {
                    ..._var.attributes,
                    'nrows': $(element).find('.value').val()
                }
            }

            if ($(element).find('.key').val() == 'x' && !has_n_cols) {
                _var.attributes = {
                    ..._var.attributes,
                    'ncols': $(element).find('.value').val()
                }
            }
        });

        let data = JSON.parse(JSON.stringify(tempate));

        data.variables.variable.push(_var);

        $('.dimension-input').each(function(i, element) {
            let key = $(element).find(".key").val()
            let value = $(element).find(".value").val();

            let dim_var = JSON.parse(JSON.stringify(variable_template));

            dim_var.name = key;
            dim_var.dimensions = {
                ...dim_var.dimensions,
                [key]: value
            };
            dim_var.attributes = {
                ...dim_var.attributes,
                'long_name': `${key} coordinate of projection`,
                'standard_name': `projection_${key}_coordinate`,
                'units': 'Meter'
            };

            data.variables.variable.push(dim_var);
        });

        // let transverse_var = JSON.parse(JSON.stringify(variable_template));
        // transverse_var.name = 'transverse_mercator';
        // transverse_var.dimensions = {
        //     ...transverse_var.dimensions,
        //     'x': 624
        // }
        // transverse_var.attributes = {
        //     ...transverse_var.attributes,
        //     'grid_mapping_name': 'transverse_mercator',
        //     'longitude_of_central_meridian': '-93',
        //     'scale_factor_at_central_meridian': '0.9996',
        //     'false_easting': '500000',
        //     'false_northing': '0'
        // }

        // data.variables.variable.push(transverse_var);

        processPrj(data);

        let xml = toXML(data, null, 2);


        let lines_of_header = 0;

        let file_type = $("#file_type").val();

        if (file_type === "DEM") {
            lines_of_header = 6;
        } else {
            lines_of_header = 0;
        }

        async function create_nc_file() {
            let msg = await eel.create_nc_file(xml, file_name, lines_of_header)();

            console.log(msg);

            if (msg == 'done') {
                $('#successmodal').modal('show');
            }
        }

        create_nc_file();
    });

    $("#somefile").on('change', function(event) {
        console.log(event.target.files[0]);
    });

    $("#open-file-dialog").click(function() {
        let dims = {};
        let lines_of_header = 0;

        let file_type = $("#file_type").val();

        if (file_type === "DEM") {
            lines_of_header = 6;
        } else {
            lines_of_header = 0;
        }

        async function get_input_file() {
            let input_file_info = await eel.select_file(lines_of_header)();
            let input_file_info_arr = input_file_info.split(";")

            let input_file_name = input_file_info_arr[input_file_info_arr.length - 1];

            file_name = input_file_name;

            $("#input_file_name").show();
            $("#input_file_name").html(input_file_name);

            for (let i = 0; i < (input_file_info_arr.length - 1); i++) {
                let arr = input_file_info_arr[i].split(':');

                if (arr[0].toLowerCase() == 'ncols' || arr[0].toLowerCase() == 'nrows') {
                    if (arr[0].toLowerCase() == 'ncols') {
                        dims = {
                            ...dims,
                            'x': arr[1]
                        };
                    } else if (arr[0].toLowerCase() == 'nrows') {
                        dims = {
                            ...dims,
                            'y': arr[1]
                        };
                    }
                }

                let attr_input = $('.attribute-input:first').clone();

                $(attr_input.find('.key')).val(arr[0]);
                $(attr_input.find('.value')).val(arr[1]);

                $(".attribute-input:last").after(attr_input);
            }
            if (lines_of_header != 0) {
                $('.attribute-input:first').remove();
            }

            $('.attribute-input').each(function(idx, element) {
                if ($(element).find('.key').val() === 'ncols') {
                    has_n_cols = true;
                }

                if ($(element).find('.key').val() === 'nrows') {
                    has_n_rows = true;
                }
            });

            if (dims.hasOwnProperty('y') && dims.hasOwnProperty('x')) {
                let dim_input = $('.dimension-input:first');

                $(dim_input.find('.key')).val('y');
                $(dim_input.find('.value')).val(dims['y']);

                dim_input = $('.dimension-input:first').clone()

                $(dim_input.find('.key')).val('x');
                $(dim_input.find('.value')).val(dims['x']);

                $('.dimension-input:first').after(dim_input);
            }
        }

        get_input_file();
    });

    $("#open_prj_file").on('click', function() {
        async function select_prj_file() {
            prj_string = await eel.select_prj_file()();

            $("#prj_string").html(prj_string);
            $("#prj_string").show();
        };

        select_prj_file();
    });

    $("#successmodal").on('hide.bs.modal', function() {
        clearForm();
    });

    deleteField = function(element) {
        $(element).parent('div').parent('div').remove();
    }

    clearForm = function() {
        $("#input_file_name").html('');
        $("#input_file_name").hide();

        $("#prj_string").html('');
        $("#prj_string").hide();

        $("#variable-name-input").val('');

        $('.dimension-input').each(function(i, element) {
            if (i == 0) {
                $(element).find(".key").val('');
                $(element).find(".value").val('')
            } else {
                $(element).remove();
            }
        });

        $('.attribute-input').each(function(i, element) {
            if (i == 0) {
                $(element).find(".key").val('');
                $(element).find(".value").val('')
            } else {
                $(element).remove();
            }
        });
    }

    processPrj = function(data) {
        //let str = 'PROJCS[\"NAD_1983_UTM_Zone_15N\",GEOGCS[\"GCS_North_American_1983\",DATUM[\"D_North_American_1983\",SPHEROID[\"GRS_1980\",6378137.0,298.257222101]],PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]],PROJECTION[\"Transverse_Mercator\"],PARAMETER[\"False_Easting\",500000.0],PARAMETER[\"False_Northing\",0.0],PARAMETER[\"Central_Meridian\",-93.0],PARAMETER[\"Scale_Factor\",0.9996],PARAMETER[\"Latitude_Of_Origin\",0.0],UNIT[\"Meter\",1.0]]';
        let arr = getIndicesOf("PARAMETER", prj_string);

        let params = arr.map(e => {
            let temp_str = '';

            for (let i = (e + 10); prj_string[i] != ']'; i++) {
                temp_str += prj_string[i];
            }

            ret_arr = temp_str.toLocaleLowerCase().split(',');
            ret_arr[0] = ret_arr[0].substring(1, ret_arr[0].length - 1);

            return ret_arr;
        });

        let transverse_var = JSON.parse(JSON.stringify(variable_template));
        transverse_var.name = 'transverse_mercator';
        transverse_var.dimensions = {
            ...transverse_var.dimensions,
            't': 1
        }
        transverse_var.attributes = {
            ...transverse_var.attributes,
            'grid_mapping_name': 'transverse_mercator',
            // 'longitude_of_central_meridian': '-93',
            // 'scale_factor_at_central_meridian': '0.9996',
            // 'false_easting': '500000',
            // 'false_northing': '0'
        }

        params.forEach(function(element) {
            if (element[0].includes('false_easting')) {
                transverse_var.attributes = {
                    ...transverse_var.attributes,
                    'false_easting': element[1]
                }
            } else if (element[0].includes('false_northing')) {
                transverse_var.attributes = {
                    ...transverse_var.attributes,
                    'false_northing': element[1]
                }
            } else if (element[0].includes('central_meridian')) {
                transverse_var.attributes = {
                    ...transverse_var.attributes,
                    'longitude_of_central_meridian': element[1]
                }
            } else if (element[0].includes('scale_factor')) {
                transverse_var.attributes = {
                    ...transverse_var.attributes,
                    'scale_factor_at_central_meridian': element[1]
                }
            }
        });

        data.variables.variable.push(transverse_var);
    }

    getIndicesOf = function(searchStr, str, caseSensitive) {
        var searchStrLen = searchStr.length;
        if (searchStrLen == 0) {
            return [];
        }
        var startIndex = 0,
            index, indices = [];
        if (!caseSensitive) {
            str = str.toLowerCase();
            searchStr = searchStr.toLowerCase();
        }
        while ((index = str.indexOf(searchStr, startIndex)) > -1) {
            indices.push(index);
            startIndex = index + searchStrLen;
        }
        return indices;
    }
});