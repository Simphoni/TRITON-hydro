import eel

import os

import ascii_to_netcdf
import binary_to_netcdf

@eel.expose
def create_nc_file(xml_config, input_file_name, lines_of_header):
    return ascii_to_netcdf.create_nc_file(xml_config, input_file_name, lines_of_header)

@eel.expose
def select_file(lines_of_header):
    return ascii_to_netcdf.select_file(lines_of_header)

@eel.expose
def select_prj_file():
    return ascii_to_netcdf.select_prj_file()






@eel.expose
def bin_select_file(lines_of_header):
    return binary_to_netcdf.select_file(lines_of_header)

@eel.expose
def bin_select_prj_file():
    return binary_to_netcdf.select_prj_file()

@eel.expose
def bin_create_nc_file(xml_config, input_file_name, lines_of_header):
    return binary_to_netcdf.create_nc_file(xml_config, input_file_name, lines_of_header)


if not os.path.exists('config'):
    os.makedirs('config')

if not os.path.exists('prog_data'):
    os.makedirs('prog_data')
    f = open('prog_data/prjfile', 'w+')
    f.write("~/")
    f.close()

    f = open('prog_data/inputfile', 'w+')
    f.write("~/")
    f.close()

    f = open('prog_data/outputfile', 'w+')
    f.write("~/")
    f.close()

eel.init('web')
eel.start('index.html', size=(500, 400))

# read_input_file_header('D:/DAND/dem_space_separated.dem')